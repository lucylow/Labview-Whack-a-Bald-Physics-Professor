<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Students come to understand LabVIEW and control concepts.

## Metric

Games played through to the end each week
