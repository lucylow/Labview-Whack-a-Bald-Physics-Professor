# WHACK-A-PROFESSOR
- [ ] Complete playable game, five modes, scoring, keyboard/touch, sound and results.
- [ ] Main menu, leaderboard, statistics, achievements, settings and persistence.
- [ ] Verify rules with tests and desktop/mobile gameplay; save changes.