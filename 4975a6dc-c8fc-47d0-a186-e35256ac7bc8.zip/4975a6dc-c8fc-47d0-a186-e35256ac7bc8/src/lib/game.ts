export type Mode = 'Classic' | 'Sprint' | 'Endurance' | 'Quantum Chaos' | 'Golden Professor';
export type TargetKind = 'normal' | 'decoy' | 'golden';
export const modes: { name: Mode; seconds: number; description: string; label: string }[] = [
  { name: 'Classic', seconds: 30, description: 'The original lab experiment. One professor. No excuses.', label: 'THE ORIGINAL' },
  { name: 'Sprint', seconds: 15, description: 'Fast reactions. Double points. A very short office hour.', label: 'FAST & FURIOUS' },
  { name: 'Endurance', seconds: 60, description: 'Survive a minute as the experiment gets faster.', label: 'THE LONG HAUL' },
  { name: 'Quantum Chaos', seconds: 30, description: 'Multiple possibilities. Only one real professor.', label: 'EXPECT THE UNEXPECTED' },
  { name: 'Golden Professor', seconds: 30, description: 'Catch a rare golden professor for a 50-point bonus.', label: 'STRIKE GOLD' },
];
export const modeDuration = (mode: Mode) => modes.find(m => m.name === mode)?.seconds ?? 30;
export const accuracy = (hits: number, misses: number) => hits + misses === 0 ? 0 : Math.round(hits / (hits + misses) * 100);
export const comboBonus = (combo: number) => ({ 3: 5, 5: 10, 10: 25, 20: 50 })[combo] ?? 0;
export function pointsForHit(kind: TargetKind, mode: Mode, elapsed: number, combo: number) {
  if (kind === 'decoy') return -15;
  const speed = Math.max(0, Math.min(10, Math.round(10 * (1 - elapsed / 650))));
  return (mode === 'Sprint' ? 20 : 10) + speed + comboBonus(combo) + (kind === 'golden' ? 50 : 0);
}
export function randomHole(previous = -1, random = Math.random) {
  const choices = Array.from({ length: 9 }, (_, i) => i).filter(i => i !== previous);
  return choices[Math.floor(random() * choices.length)] ?? 0;
}
export type Settings = { sound: boolean; music: boolean; intensity: 'Low' | 'Normal' | 'High'; reducedMotion: boolean; difficulty: 'Easy' | 'Normal' | 'Hard'; name: string };
export const defaultSettings: Settings = { sound: true, music: false, intensity: 'Normal', reducedMotion: false, difficulty: 'Normal', name: 'Engineering Student' };
export type Round = { id: string; score: number; hits: number; misses: number; bestCombo: number; goldenHits: number; mode: Mode; accuracy: number; seconds: number; date: string; xp: number };
export type Profile = { xp: number; lifetimeScore: number; highScore: number; gamesPlayed: number; totalHits: number; totalMisses: number };
export const mockPlayer: Profile = { xp: 485, lifetimeScore: 4850, highScore: 920, gamesPlayed: 12, totalHits: 326, totalMisses: 81 };
export type Save = { settings: Settings; player: Profile; rounds: Round[]; unlocked: string[] };
export const mockRounds: Round[] = [
  { id: 'mock-1', score: 420, hits: 32, misses: 6, bestCombo: 9, goldenHits: 0, mode: 'Classic', accuracy: 84, seconds: 30, date: '2026-11-10T15:00:00.000Z', xp: 42 },
  { id: 'mock-2', score: 610, hits: 28, misses: 3, bestCombo: 12, goldenHits: 0, mode: 'Sprint', accuracy: 90, seconds: 15, date: '2026-11-12T15:00:00.000Z', xp: 61 },
  { id: 'mock-3', score: 920, hits: 58, misses: 11, bestCombo: 15, goldenHits: 1, mode: 'Endurance', accuracy: 84, seconds: 60, date: '2026-11-14T15:00:00.000Z', xp: 92 },
  { id: 'mock-4', score: 380, hits: 27, misses: 9, bestCombo: 6, goldenHits: 0, mode: 'Quantum Chaos', accuracy: 75, seconds: 30, date: '2026-11-16T15:00:00.000Z', xp: 38 },
  { id: 'mock-5', score: 540, hits: 30, misses: 5, bestCombo: 10, goldenHits: 2, mode: 'Golden Professor', accuracy: 86, seconds: 30, date: '2026-11-18T15:00:00.000Z', xp: 54 },
  { id: 'mock-6', score: 470, hits: 34, misses: 7, bestCombo: 11, goldenHits: 0, mode: 'Classic', accuracy: 83, seconds: 30, date: '2026-11-19T15:00:00.000Z', xp: 47 },
  { id: 'mock-7', score: 700, hits: 31, misses: 2, bestCombo: 14, goldenHits: 0, mode: 'Sprint', accuracy: 94, seconds: 15, date: '2026-11-19T15:00:00.000Z', xp: 70 },
  { id: 'mock-8', score: 350, hits: 25, misses: 10, bestCombo: 5, goldenHits: 0, mode: 'Quantum Chaos', accuracy: 71, seconds: 30, date: '2026-11-20T15:00:00.000Z', xp: 35 },
  { id: 'mock-9', score: 820, hits: 52, misses: 9, bestCombo: 13, goldenHits: 0, mode: 'Endurance', accuracy: 85, seconds: 60, date: '2026-11-20T15:00:00.000Z', xp: 82 },
  { id: 'mock-10', score: 640, hits: 33, misses: 4, bestCombo: 12, goldenHits: 3, mode: 'Golden Professor', accuracy: 89, seconds: 30, date: '2026-11-20T15:00:00.000Z', xp: 64 },
];
export const initialSave: Save = { settings: defaultSettings, player: mockPlayer, rounds: mockRounds, unlocked: ['first', 'combo'] };
export const STORAGE_KEY = 'whack-a-professor-v1';
export const achievements = [
  { id: 'first', name: 'First Strike', description: 'Hit your first professor', goal: 1 },
  { id: 'combo', name: 'Combo Machine', description: 'Reach a 10-hit combo', goal: 10 },
  { id: 'golden', name: 'Golden Touch', description: 'Hit a golden professor', goal: 1 },
  { id: 'quantum', name: 'Quantum Survivor', description: 'Complete Quantum Chaos', goal: 1 },
  { id: 'perfect', name: 'Perfect Lab', description: 'Finish with 100% accuracy', goal: 100 },
  { id: 'panic', name: 'Professor Panic', description: 'Hit 100 professors', goal: 100 },
  { id: 'speed', name: 'Speed Demon', description: 'Hit 20 professors in Sprint', goal: 20 },
  { id: 'endurance', name: 'Endurance Expert', description: 'Complete Endurance', goal: 1 },
];
export function achievementProgress(id: string, rounds: Round[]) {
  const max = (fn: (r: Round) => number) => Math.max(0, ...rounds.map(fn));
  switch (id) {
    case 'first': return max(r => r.hits);
    case 'combo': return max(r => r.bestCombo);
    case 'golden': return rounds.reduce((n, r) => n + r.goldenHits, 0);
    case 'quantum': return rounds.filter(r => r.mode === 'Quantum Chaos').length;
    case 'perfect': return max(r => r.accuracy);
    case 'panic': return rounds.reduce((n, r) => n + r.hits, 0);
    case 'speed': return max(r => r.mode === 'Sprint' ? r.hits : 0);
    case 'endurance': return rounds.filter(r => r.mode === 'Endurance').length;
    default: return 0;
  }
}
export function saveRound(save: Save, round: Round): Save {
  const rounds = [...save.rounds, round];
  return { ...save, rounds, player: { xp: save.player.xp + round.xp, lifetimeScore: save.player.lifetimeScore + round.score, highScore: Math.max(save.player.highScore, round.score), gamesPlayed: save.player.gamesPlayed + 1, totalHits: save.player.totalHits + round.hits, totalMisses: save.player.totalMisses + round.misses }, unlocked: [...new Set([...save.unlocked, ...achievements.filter(a => achievementProgress(a.id, rounds) >= a.goal).map(a => a.id)])] };
}
export type LeaderRow = { name: string; score: number; mode: Mode; accuracy: number; local?: boolean };
export const mockLeaderboard: LeaderRow[] = [
  { name: 'NewtonFan99', score: 9850, mode: 'Endurance', accuracy: 96 },
  { name: 'QuantumKing', score: 9200, mode: 'Classic', accuracy: 93 },
  { name: 'LabRat42', score: 8750, mode: 'Sprint', accuracy: 91 },
  { name: 'OhmMyGod', score: 8100, mode: 'Quantum Chaos', accuracy: 89 },
  { name: 'EinsteinEnjoyer', score: 7600, mode: 'Classic', accuracy: 87 },
  { name: 'ProfessorSlayer', score: 7100, mode: 'Endurance', accuracy: 86 },
  { name: 'CircuitBreaker', score: 6500, mode: 'Sprint', accuracy: 84 },
  { name: 'TheLabPartner', score: 5900, mode: 'Classic', accuracy: 82 },
  { name: 'PiRate', score: 5300, mode: 'Quantum Chaos', accuracy: 80 },
  { name: 'LateForLab', score: 4800, mode: 'Classic', accuracy: 78 },
  { name: 'GoldDigger', score: 4550, mode: 'Golden Professor', accuracy: 88 },
  { name: 'SchrodingersCat', score: 4300, mode: 'Quantum Chaos', accuracy: 76 },
  { name: 'TA_Terminator', score: 4100, mode: 'Sprint', accuracy: 83 },
  { name: 'OfficeHourHero', score: 3900, mode: 'Endurance', accuracy: 79 },
  { name: 'MidtermMenace', score: 3650, mode: 'Classic', accuracy: 74 },
  { name: 'Tesla_Tapper', score: 3400, mode: 'Golden Professor', accuracy: 81 },
  { name: 'CaffeineCoder', score: 3150, mode: 'Sprint', accuracy: 72 },
  { name: 'GradeCurveGod', score: 2900, mode: 'Endurance', accuracy: 70 },
  { name: 'SyllabusSkipper', score: 2600, mode: 'Classic', accuracy: 68 },
  { name: 'Entropy_Ed', score: 2350, mode: 'Quantum Chaos', accuracy: 65 },
  { name: 'BunsenBurner', score: 2100, mode: 'Sprint', accuracy: 64 },
  { name: 'PeerReviewPete', score: 1900, mode: 'Classic', accuracy: 62 },
  { name: 'VoltageVic', score: 1750, mode: 'Golden Professor', accuracy: 71 },
  { name: 'FinalsFrenzy', score: 1600, mode: 'Endurance', accuracy: 60 },
  { name: 'HeisenbergHits', score: 1450, mode: 'Quantum Chaos', accuracy: 58 },
  { name: 'DeanDodger', score: 1300, mode: 'Classic', accuracy: 57 },
  { name: 'LabCoatLuna', score: 1150, mode: 'Sprint', accuracy: 55 },
  { name: 'ThesisThrasher', score: 1000, mode: 'Endurance', accuracy: 53 },
  { name: 'CurieCrusher', score: 900, mode: 'Golden Professor', accuracy: 66 },
  { name: 'PopQuizPanic', score: 750, mode: 'Classic', accuracy: 50 },
];
export function leaderboardRows(save: Save, search = '', mode = 'All modes', sort: 'score' | 'accuracy' = 'score') {
  return [...mockLeaderboard, ...save.rounds.map(r => ({ name: save.settings.name, score: r.score, mode: r.mode, accuracy: r.accuracy, local: true }))].filter(r => r.name.toLowerCase().includes(search.toLowerCase()) && (mode === 'All modes' || r.mode === mode)).sort((a, b) => b[sort] - a[sort]);
}
export function readSave(storage: Pick<Storage, 'getItem'>): Save {
  try {
    const raw: unknown = JSON.parse(storage.getItem(STORAGE_KEY) ?? 'null');
    if (!raw || typeof raw !== 'object') return initialSave;
    const value = raw as Partial<Save>;
    return { settings: { ...defaultSettings, ...value.settings }, player: { ...mockPlayer, ...value.player }, rounds: Array.isArray(value.rounds) ? value.rounds : [], unlocked: Array.isArray(value.unlocked) ? value.unlocked : initialSave.unlocked };
  } catch { return initialSave; }
}