// Synthetic teaching/demo data. Never real students or live hardware readings.
export type Level = 'Beginner' | 'Intermediate' | 'Advanced';
export type Topic = { id: string; title: string; level: Level; minutes: number; summary: string; points: string[]; gameLink: string };
export const topics: Topic[] = [
  { id: 'fundamentals', title: 'LabVIEW fundamentals', level: 'Beginner', minutes: 12, summary: 'LabVIEW is a graphical dataflow programming environment: a node runs once all its inputs arrive.', points: ['Front Panel = user interface; Block Diagram = code', 'Wires carry data, colored by type', 'Controls are inputs, indicators are outputs'], gameLink: 'The Start button is a Boolean control; the score display is a numeric indicator.' },
  { id: 'loops', title: 'Loops and timing', level: 'Beginner', minutes: 15, summary: 'While Loops repeat until a stop condition; For Loops run N times. Wait functions keep the CPU free.', points: ['While Loop always runs at least once', 'Shift registers carry values between iterations', 'Use Wait (ms) to pace a loop'], gameLink: 'The round timer is a While Loop that stops when time reaches zero.' },
  { id: 'state', title: 'Decisions and state machines', level: 'Intermediate', minutes: 18, summary: 'Case Structures pick code by value; a state machine is a loop + case structure + shift register.', points: ['Use an enum for state names', 'Every state chooses the next state', 'Add a default case to handle surprises'], gameLink: 'Menu → Playing → Paused → Result is a classic state machine.' },
  { id: 'arrays', title: 'Arrays and clusters', level: 'Intermediate', minutes: 16, summary: 'Arrays hold many values of one type; clusters bundle different types together.', points: ['Auto-indexing builds arrays from loops', 'Bundle/Unbundle by Name keeps code readable', 'Arrays are zero-indexed'], gameLink: 'The 3×3 board is an array of 9 Boolean holes.' },
  { id: 'debugging', title: 'Debugging and error handling', level: 'Intermediate', minutes: 14, summary: 'Highlight execution, probes and breakpoints reveal dataflow; error clusters chain status through code.', points: ['Wire error in/out to enforce order', 'Probes show live wire values', 'Never ignore the error cluster'], gameLink: 'A missed click is a recoverable error: the round continues.' },
  { id: 'daq', title: 'DAQ and instrumentation', level: 'Advanced', minutes: 20, summary: 'Data acquisition turns physical signals into numbers via channels, sample rates and scaling.', points: ['Sample at least 2× the highest frequency (Nyquist)', 'Calibrate sensors against known references', 'Label units on every channel'], gameLink: 'Your mouse is the sensor; each hit is a sampled event.' },
  { id: 'signals', title: 'Signal processing', level: 'Advanced', minutes: 22, summary: 'Filters remove noise, FFTs reveal frequencies, averaging trades speed for stability.', points: ['Low-pass filters smooth noise', 'FFT moves from time to frequency domain', 'Aliasing appears when sampling too slowly'], gameLink: 'Decoy professors are noise; the real one is the signal.' },
  { id: 'control', title: 'Control systems (PID)', level: 'Advanced', minutes: 24, summary: 'A PID controller corrects error using Proportional, Integral and Derivative terms.', points: ['P reacts to present error', 'I removes steady-state error', 'D dampens overshoot'], gameLink: 'Your aim correcting toward the professor is a human PID loop.' },
  { id: 'datatypes', title: 'Data types and coercion', level: 'Beginner', minutes: 10, summary: 'Wire colors show type: orange = floating point, blue = integer, green = Boolean, pink = string.', points: ['Coercion dots mark hidden conversions', 'Pick the smallest type that fits', 'Avoid coercion inside fast loops'], gameLink: 'Score is an integer; accuracy is a floating-point percentage.' },
  { id: 'subvis', title: 'SubVIs and modularity', level: 'Intermediate', minutes: 14, summary: 'A SubVI packages code with an icon and connector pane, like a function.', points: ['Inputs on the left, outputs on the right', 'Put error in/out on the bottom corners', 'Give every SubVI a clear icon'], gameLink: 'Points-for-hit is a perfect SubVI: inputs in, score out.' },
  { id: 'fileio', title: 'File I/O', level: 'Intermediate', minutes: 12, summary: 'Write results to CSV or text files so experiments can be analyzed later.', points: ['Open → Write → Close, always', 'Use headers and units in CSV files', 'Check the error cluster after each step'], gameLink: 'Your round history could be exported as a CSV lab log.' },
  { id: 'charts', title: 'Charts and graphs', level: 'Beginner', minutes: 10, summary: 'Waveform Charts append points live; Waveform Graphs plot a whole array at once.', points: ['Chart = scrolling history', 'Graph = full dataset', 'Always label axes and units'], gameLink: 'A live hit-rate chart would be a Waveform Chart.' },
];
export const glossary = [
  ['VI', 'Virtual Instrument — a LabVIEW program with a Front Panel and Block Diagram.'],
  ['SubVI', 'A VI used inside another VI, like a function.'],
  ['Connector pane', 'The terminal layout that defines a SubVI\'s inputs and outputs.'],
  ['Shift register', 'Loop terminal that passes a value to the next iteration.'],
  ['Dataflow', 'Execution model where nodes run when all inputs are available.'],
  ['Sample rate', 'How many measurements are taken per second (Hz).'],
  ['Nyquist rate', 'Twice the highest frequency in a signal; the minimum safe sample rate.'],
  ['Coercion dot', 'Marks where LabVIEW converts a value to another data type.'],
  ['Error cluster', 'Bundle of status, code and source passed between nodes.'],
  ['Reaction time', 'Delay between a stimulus and a response, typically 200–300 ms.'],
  ['Waveform Chart', 'Indicator that appends new points and scrolls like a strip recorder.'],
  ['Case Structure', 'Runs one of several subdiagrams depending on an input value.'],
  ['Enum', 'Integer type with named values, ideal for state machine states.'],
  ['Auto-indexing', 'Loop tunnel that builds or splits arrays one element per iteration.'],
  ['Highlight execution', 'Debug mode that animates data flowing along wires.'],
] as const;
export type Question = { topic: string; q: string; options: string[]; answer: number; why: string };
export const questions: Question[] = [
  { topic: 'fundamentals', q: 'When does a LabVIEW node execute?', options: ['Top to bottom', 'When all inputs arrive', 'Every 10 ms', 'Randomly'], answer: 1, why: 'Dataflow: a node runs once every input has data.' },
  { topic: 'fundamentals', q: 'Where do you build the user interface?', options: ['Block Diagram', 'Front Panel', 'Project Explorer', 'Error list'], answer: 1, why: 'Controls and indicators live on the Front Panel.' },
  { topic: 'loops', q: 'How many times does a While Loop run at minimum?', options: ['0', '1', '2', 'Unlimited'], answer: 1, why: 'The condition is checked after each iteration.' },
  { topic: 'loops', q: 'What carries a value to the next loop iteration?', options: ['Tunnel', 'Shift register', 'Probe', 'Local variable'], answer: 1, why: 'Shift registers store the previous iteration\'s value.' },
  { topic: 'arrays', q: 'Index of the first array element?', options: ['1', '0', '-1', 'Depends'], answer: 1, why: 'LabVIEW arrays are zero-indexed.' },
  { topic: 'state', q: 'A state machine combines a loop, a shift register and…', options: ['A Case Structure', 'An FFT', 'A chart', 'A SubVI'], answer: 0, why: 'The Case Structure runs the current state.' },
  { topic: 'daq', q: 'A 50 Hz signal needs a sample rate of at least…', options: ['25 Hz', '50 Hz', '100 Hz', '1 kHz'], answer: 2, why: 'Nyquist: at least twice the highest frequency.' },
  { topic: 'control', q: 'Which PID term removes steady-state error?', options: ['P', 'I', 'D', 'None'], answer: 1, why: 'The Integral term accumulates past error.' },
  { topic: 'signals', q: 'Which filter smooths high-frequency noise?', options: ['High-pass', 'Low-pass', 'Notch at DC', 'None'], answer: 1, why: 'Low-pass filters keep slow changes and drop fast noise.' },
  { topic: 'debugging', q: 'Why wire the error cluster through nodes?', options: ['Color', 'Enforce order and report failures', 'Speed', 'Required by law'], answer: 1, why: 'It forces sequence and carries errors downstream.' },
  { topic: 'datatypes', q: 'What color is a Boolean wire?', options: ['Orange', 'Blue', 'Green', 'Pink'], answer: 2, why: 'Booleans are green; floats orange, integers blue, strings pink.' },
  { topic: 'subvis', q: 'Where should error in/out go on a connector pane?', options: ['Top center', 'Bottom corners', 'Anywhere', 'Not wired'], answer: 1, why: 'Bottom-left in, bottom-right out is the convention.' },
  { topic: 'charts', q: 'Which plots live data with scrolling history?', options: ['Waveform Graph', 'Waveform Chart', 'XY Graph', 'Table'], answer: 1, why: 'Charts keep a history buffer and append points.' },
  { topic: 'fileio', q: 'Correct order for file writing?', options: ['Write, Open, Close', 'Open, Write, Close', 'Close, Open, Write', 'Write only'], answer: 1, why: 'Open the reference, write, then always close it.' },
];
const handles = ['OhmRunner','FourierFan','LabGremlin','NyquistNinja','KirchhoffKid','BodePlotBea','ShiftRegSam','DataflowDee','LoopLord','CaseStructCass','ArrayAri','ClusterCleo','ProbePriya','WireWizard','SubVISol','PIDPablo','FFTFinn','SampleRateRae','GainGrace','DeltaTDev','ThermoTheo','StrainGaugeSky','VoltVera','TorqueTomas'];
const tracks = ['Mechanical','Electrical','Biomedical','Physics','Computer'];
const levels: Level[] = ['Beginner','Intermediate','Advanced'];
export const demoStudents = handles.map((name, i) => ({ name, track: tracks[i % 5]!, level: levels[i % 3]!, xp: 300 + ((i * 137) % 1900), lessons: 1 + ((i * 3) % topics.length), quizAccuracy: 55 + ((i * 7) % 43), topic: topics[(i * 5) % topics.length]!.id }));
export const reactionDataset = Array.from({ length: 12 }, (_, i) => ({ trial: i + 1, ms: 310 - i * 6 + ((i * 37) % 23) }));
export type LvComponent = { name: string; kind: 'Control' | 'Indicator' | 'Structure' | 'Function'; palette: string; wire: string; use: string };
export const lvComponents: LvComponent[] = [
  { name: 'Boolean Push Button', kind: 'Control', palette: 'Boolean', wire: 'Green (Boolean)', use: 'Start or stop a round.' },
  { name: 'Numeric Knob', kind: 'Control', palette: 'Numeric', wire: 'Orange (DBL)', use: 'Adjust spawn speed.' },
  { name: 'Slide Control', kind: 'Control', palette: 'Numeric', wire: 'Orange (DBL)', use: 'Set round length in seconds.' },
  { name: 'Enum Ring', kind: 'Control', palette: 'Ring & Enum', wire: 'Blue (U16)', use: 'Pick a game mode.' },
  { name: 'String Control', kind: 'Control', palette: 'String & Path', wire: 'Pink (String)', use: 'Enter the player name.' },
  { name: 'LED', kind: 'Indicator', palette: 'Boolean', wire: 'Green (Boolean)', use: 'Light up the active hole.' },
  { name: 'Numeric Indicator', kind: 'Indicator', palette: 'Numeric', wire: 'Blue (I32)', use: 'Show the score.' },
  { name: 'Gauge', kind: 'Indicator', palette: 'Numeric', wire: 'Orange (DBL)', use: 'Display accuracy %.' },
  { name: 'Waveform Chart', kind: 'Indicator', palette: 'Graph', wire: 'Orange (DBL)', use: 'Plot hits per second live.' },
  { name: 'Boolean Array (3×3)', kind: 'Indicator', palette: 'Array, Matrix & Cluster', wire: 'Thick green (Array)', use: 'Represent the professor board.' },
  { name: 'While Loop', kind: 'Structure', palette: 'Structures', wire: '—', use: 'Run the game until time is up.' },
  { name: 'For Loop', kind: 'Structure', palette: 'Structures', wire: '—', use: 'Initialize all 9 holes.' },
  { name: 'Case Structure', kind: 'Structure', palette: 'Structures', wire: '—', use: 'Handle hit, miss or decoy.' },
  { name: 'Event Structure', kind: 'Structure', palette: 'Structures', wire: '—', use: 'React to mouse clicks without polling.' },
  { name: 'Shift Register', kind: 'Structure', palette: 'Structures', wire: 'Matches data', use: 'Carry score and combo between iterations.' },
  { name: 'Wait (ms)', kind: 'Function', palette: 'Timing', wire: 'Blue (U32)', use: 'Pace the spawn loop.' },
  { name: 'Tick Count (ms)', kind: 'Function', palette: 'Timing', wire: 'Blue (U32)', use: 'Measure reaction time.' },
  { name: 'Random Number (0–1)', kind: 'Function', palette: 'Numeric', wire: 'Orange (DBL)', use: 'Choose the next hole.' },
  { name: 'Index Array', kind: 'Function', palette: 'Array', wire: 'Matches element', use: 'Read one hole from the board.' },
  { name: 'Bundle by Name', kind: 'Function', palette: 'Cluster', wire: 'Brown/pink (Cluster)', use: 'Pack round results together.' },
  { name: 'Write Delimited Spreadsheet', kind: 'Function', palette: 'File I/O', wire: 'Pink (String)', use: 'Save round history to CSV.' },
  { name: 'Simple Error Handler', kind: 'Function', palette: 'Dialog & UI', wire: 'Yellow (Error)', use: 'Report failures to the player.' },
];
