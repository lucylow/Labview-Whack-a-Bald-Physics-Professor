import { createFileRoute, Link } from '@tanstack/react-router';
import { useEffect, useState } from 'react';
import { ArrowLeft, BookOpen, CheckCircle2, FlaskConical, GraduationCap, Search, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { lvComponents, demoStudents, glossary, questions, reactionDataset, topics, type Level } from '@/lib/learning';

export const Route = createFileRoute('/lab')({
  head: () => ({ meta: [
    { title: 'Learning Lab — WHACK-A-PROFESSOR' },
    { name: 'description', content: 'Learn LabVIEW basics, loops, state machines, DAQ and PID control with quizzes and sample experiments.' },
    { property: 'og:title', content: 'Learning Lab — WHACK-A-PROFESSOR' },
    { property: 'og:description', content: 'LabVIEW lessons, practice quizzes and sample experiments inside the arcade.' },
    { property: 'og:type', content: 'website' }, { name: 'twitter:card', content: 'summary_large_image' },
  ] }),
  component: Lab,
});
const KEY = 'whack-a-professor-lab-v1';
type Tab = 'lessons' | 'quiz' | 'experiment' | 'glossary' | 'students' | 'components';
function Lab() {
  const [tab, setTab] = useState<Tab>('lessons');
  const [done, setDone] = useState<string[]>([]);
  useEffect(() => { try { setDone(JSON.parse(localStorage.getItem(KEY) ?? '[]')); } catch { /* ignore */ } }, []);
  const toggle = (id: string) => setDone(d => { const n = d.includes(id) ? d.filter(x => x !== id) : [...d, id]; try { localStorage.setItem(KEY, JSON.stringify(n)); } catch { /* ignore */ } return n; });
  const tabs: [Tab, string, typeof BookOpen][] = [['lessons', 'Lessons', BookOpen], ['quiz', 'Practice quiz', GraduationCap], ['experiment', 'Sample experiment', FlaskConical], ['components', 'Components', FlaskConical], ['glossary', 'Glossary', Search], ['students', 'Demo students', Users]];
  return <div className="arcade-app"><main className="main-container lab-page">
    <Link to="/" className="lab-back"><ArrowLeft size={16}/> Back to the game</Link>
    <div className="lab-label"><span/> LEARNING LAB</div>
    <h1 className="lab-title">Engineering, one professor at a time.</h1>
    <p className="lab-progress">Your progress: {done.length}/{topics.length} lessons complete <span className="lab-bar"><span style={{ width: `${done.length / topics.length * 100}%` }}/></span></p>
    <nav className="lab-tabs" aria-label="Learning Lab sections">{tabs.map(([id, label, Icon]) => <Button key={id} variant="ghost" className={tab === id ? 'nav-active' : ''} aria-pressed={tab === id} onClick={() => setTab(id)}><Icon/> {label}</Button>)}</nav>
    {tab === 'lessons' && <Lessons done={done} toggle={toggle}/>}
    {tab === 'quiz' && <Quiz/>}
    {tab === 'experiment' && <Experiment/>}
    {tab === 'components' && <Components/>}
    {tab === 'glossary' && <Glossary/>}
    {tab === 'students' && <Students/>}
  </main></div>;
}
function Lessons({ done, toggle }: { done: string[]; toggle: (id: string) => void }) {
  const [q, setQ] = useState(''); const [lvl, setLvl] = useState<'All' | Level>('All');
  const list = topics.filter(t => (lvl === 'All' || t.level === lvl) && (t.title + t.summary).toLowerCase().includes(q.toLowerCase()));
  return <><div className="filter-row"><label className="search-input"><Search size={17}/><input value={q} onChange={e => setQ(e.target.value)} placeholder="Search lessons" aria-label="Search lessons"/></label><select value={lvl} onChange={e => setLvl(e.target.value as 'All' | Level)} aria-label="Filter by level"><option>All</option><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select></div>
  {list.length === 0 ? <p className="lab-empty">No lessons match. Try another search.</p> : <div className="lab-grid">{list.map(t => <article key={t.id} className="lab-card"><div className="lab-meta"><span>{t.level}</span><span>{t.minutes} min</span></div><h3>{t.title}</h3><p>{t.summary}</p><ul>{t.points.map(p => <li key={p}>{p}</li>)}</ul><p className="lab-game"><strong>In the game:</strong> {t.gameLink}</p><Button variant={done.includes(t.id) ? 'ghost' : 'arcade'} onClick={() => toggle(t.id)}>{done.includes(t.id) ? <><CheckCircle2/> Completed</> : 'Mark complete'}</Button></article>)}</div>}</>;
}
function Quiz() {
  const [i, setI] = useState(0); const [pick, setPick] = useState<number | null>(null); const [score, setScore] = useState(0);
  if (i >= questions.length) return <div className="lab-card"><h3>Quiz complete: {score}/{questions.length}</h3><p>{score >= 8 ? 'Excellent lab work!' : 'Review the lessons and try again — mistakes are data.'}</p><Button variant="arcade" onClick={() => { setI(0); setScore(0); setPick(null); }}>Try again</Button></div>;
  const q = questions[i]!;
  return <div className="lab-card"><div className="lab-meta"><span>Question {i + 1} of {questions.length}</span><span>Score {score}</span></div><h3>{q.q}</h3><div className="quiz-options">{q.options.map((o, k) => <Button key={o} variant="ghost" disabled={pick !== null} className={pick === null ? '' : k === q.answer ? 'quiz-right' : k === pick ? 'quiz-wrong' : ''} onClick={() => { setPick(k); if (k === q.answer) setScore(s => s + 1); }}>{o}</Button>)}</div>{pick !== null && <><p role="status">{pick === q.answer ? 'Correct! ' : 'Not quite. '}{q.why}</p><Button variant="arcade" onClick={() => { setI(i + 1); setPick(null); }}>Next</Button></>}</div>;
}
function Experiment() {
  const max = Math.max(...reactionDataset.map(d => d.ms)); const avg = Math.round(reactionDataset.reduce((s, d) => s + d.ms, 0) / reactionDataset.length);
  return <div className="lab-card"><div className="panel-note"><span className="demo-badge">SAMPLE EXPERIMENT</span><span>Synthetic data, not a live measurement.</span></div><h3>Reaction time across 12 trials</h3><p>Average {avg} ms. Practice shortens reaction time — your brain learns where the professor appears.</p><div className="lab-chart" role="img" aria-label={`Bar chart of reaction times, average ${avg} milliseconds`}>{reactionDataset.map(d => <div key={d.trial} className="lab-col"><span style={{ height: `${d.ms / max * 100}%` }}/><small>{d.trial}</small></div>)}</div><p className="lab-game">Physics link: a 250 ms delay at 1 m/s hand speed means 25 cm of travel before you even react.</p></div>;
}
function Glossary() {
  const [q, setQ] = useState(''); const list = glossary.filter(([t, d]) => (t + d).toLowerCase().includes(q.toLowerCase()));
  return <><label className="search-input"><Search size={17}/><input value={q} onChange={e => setQ(e.target.value)} placeholder="Search terms" aria-label="Search glossary"/></label><dl className="lab-glossary">{list.map(([t, d]) => <div key={t}><dt>{t}</dt><dd>{d}</dd></div>)}</dl>{list.length === 0 && <p className="lab-empty">No terms found.</p>}</>;
}
function Students() {
  const [lvl, setLvl] = useState<'All' | Level>('All'); const [topic, setTopic] = useState('All');
  const list = demoStudents.filter(s => (lvl === 'All' || s.level === lvl) && (topic === 'All' || s.topic === topic));
  return <><div className="panel-note"><span className="demo-badge">DEMO DATA</span><span>Fictional learners for illustration only.</span></div><div className="filter-row"><select value={lvl} onChange={e => setLvl(e.target.value as 'All' | Level)} aria-label="Filter by level"><option>All</option><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select><select value={topic} onChange={e => setTopic(e.target.value)} aria-label="Filter by topic"><option>All</option>{topics.map(t => <option key={t.id} value={t.id}>{t.title}</option>)}</select></div>
  {list.length === 0 ? <p className="lab-empty">No students match these filters.</p> : <div className="lab-grid">{list.map(s => <article key={s.name} className="lab-card"><h3>{s.name}</h3><div className="lab-meta"><span>{s.track}</span><span>{s.level}</span></div><p>{s.xp} XP · {s.lessons} lessons · {s.quizAccuracy}% quiz accuracy</p><p className="lab-game">Favorite: {topics.find(t => t.id === s.topic)?.title}</p></article>)}</div>}</>;
}
function Components() {
  const [kind, setKind] = useState('All'); const list = lvComponents.filter(c => kind === 'All' || c.kind === kind);
  return <><div className="panel-note"><span className="demo-badge">MOCK PALETTE</span><span>Sample LabVIEW parts mapped to the game.</span></div><div className="filter-row"><select value={kind} onChange={e => setKind(e.target.value)} aria-label="Filter by type"><option>All</option><option>Control</option><option>Indicator</option><option>Structure</option><option>Function</option></select></div><div className="lab-grid">{list.map(c => <article key={c.name} className="lab-card"><div className="lab-meta"><span>{c.kind}</span><span>{c.palette}</span></div><h3>{c.name}</h3><p>{c.use}</p><p className="lab-game">Wire: {c.wire}</p></article>)}</div></>;
}
