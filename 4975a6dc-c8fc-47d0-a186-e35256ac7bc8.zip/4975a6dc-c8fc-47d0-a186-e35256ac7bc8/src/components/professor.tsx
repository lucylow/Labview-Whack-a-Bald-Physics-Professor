import { useId } from 'react';
export type Expression = 'normal' | 'surprised' | 'angry' | 'dizzy' | 'laughing' | 'shocked' | 'defeated' | 'golden';
export function Professor({ expression = 'normal', textbook = false, className = '' }: { expression?: Expression; textbook?: boolean; className?: string }) {
  const id = useId().replaceAll(':', '');
  const dizzy = expression === 'dizzy' || expression === 'defeated';
  return <svg viewBox="0 0 400 430" role="img" aria-label={`Fictional bald physics professor, ${expression}`} className={`professor-art ${expression === 'golden' ? 'golden-art' : ''} ${className}`}>
    <defs><linearGradient id={`${id}coat`} x1="0" y1="0" x2="1" y2="1"><stop className="coat-light"/><stop offset="1" className="coat-shade"/></linearGradient><linearGradient id={`${id}skin`} x1="0" x2="1" y1="0" y2="1"><stop className="skin-light"/><stop offset="1" className="skin-shade"/></linearGradient></defs>
    <g strokeLinecap="round" strokeLinejoin="round">
      <path d="M90 420 80 292Q84 242 148 230H253Q309 238 322 293L341 420Z" fill={`url(#${id}coat)`} className="ink-outline" strokeWidth="7"/>
      <path d="M159 230 151 419H247L244 230Z" className="shirt-fill ink-outline" strokeWidth="5"/>
      <path d="m151 234-33 25 31 47-22 10 23 103M245 235l33 26-28 44 22 13-25 101" className="coat-detail" strokeWidth="5"/>
      <path d="M177 207v36q23 28 47 0v-36" fill={`url(#${id}skin)`} className="ink-outline" strokeWidth="5"/>
      <ellipse cx="105" cy="155" rx="21" ry="28" className="skin-fill ink-outline" strokeWidth="6"/><ellipse cx="294" cy="155" rx="21" ry="28" className="skin-fill ink-outline" strokeWidth="6"/>
      <path d="M102 148Q94 50 160 30Q211 8 259 42Q303 70 296 151L287 199Q258 244 200 245Q141 241 113 198Z" fill={`url(#${id}skin)`} className="ink-outline" strokeWidth="7"/>
      <path d="M135 67q25-29 48-28" className="skin-highlight" strokeWidth="10"/>
      <path d="M104 120 91 101M105 107 90 88M291 119l19-20M293 105l15-22" className="hair-line" strokeWidth="8"/>
      <path d={expression === 'angry' ? 'M124 110l42 15M229 125l44-16' : 'M121 110q23-22 49-5M231 103q27-16 46 9'} className="eyebrow-line" strokeWidth="12"/>
      <circle cx="151" cy="148" r="37" className="lens-fill ink-outline" strokeWidth="7"/><circle cx="251" cy="148" r="37" className="lens-fill ink-outline" strokeWidth="7"/>
      <path d="M189 141q12-9 24 0M112 141l-11-5M289 141l9-5" className="ink-line" strokeWidth="7"/>
      {dizzy ? <g className="ink-line" strokeWidth="5"><path d="m139 138 23 22m0-22-23 22m100-22 23 22m0-22-23 22"/></g> : <g className="pupil-fill"><ellipse cx="156" cy="149" rx="8" ry="12"/><ellipse cx="245" cy="149" rx="8" ry="12"/><circle cx="159" cy="145" r="3" className="eye-glint"/><circle cx="248" cy="145" r="3" className="eye-glint"/></g>}
      <path d="M194 143q-8 29-16 37 22 13 41 0" className="nose-line" strokeWidth="5"/>
      <ellipse cx="133" cy="188" rx="16" ry="8" className="cheek-fill"/><ellipse cx="268" cy="188" rx="16" ry="8" className="cheek-fill"/>
      {expression === 'shocked' || expression === 'surprised' ? <ellipse cx="202" cy="213" rx="14" ry="17" className="mouth-fill"/> : <><path d="M168 204q33 18 66-1-8 31-33 30-23 0-33-29Z" className="mouth-fill ink-outline" strokeWidth="4"/><path d="m172 207 58-1-5 10h-47Z" className="teeth-fill"/><path d="M188 227q14-12 28-2" className="tongue-line" strokeWidth="6"/></>}
      <path d="m200 257-29-16-3 33 32-12 32 12-2-33Z" className="bow-fill ink-outline" strokeWidth="5"/><circle cx="200" cy="257" r="8" className="bow-fill ink-outline" strokeWidth="3"/>
      <path d="M274 332h34v37h-34Z" className="coat-detail" strokeWidth="4"/><path d="M286 333v-24" className="pen-line" strokeWidth="7"/>
      {textbook && <g transform="rotate(-12 135 347)"><path d="M62 284h128v126H62Z" className="book-fill ink-outline" strokeWidth="6"/><path d="M73 284v126" className="book-spine" strokeWidth="5"/><text x="127" y="324" textAnchor="middle" className="book-title">PHYSICS</text><text x="129" y="368" textAnchor="middle" className="book-equation">F = ma</text><path d="M65 373q-29-8-35 11-2 22 24 27l29 2q17-3 13-13-1-7-14-9 23 1 21-10-3-8-38-8Z" fill={`url(#${id}skin)`} className="ink-outline" strokeWidth="5"/></g>}
      {textbook && <g><path d="M297 314q-19-30 2-46l21-14-8-26q-3-15 9-17 10-2 15 17l8 22q30-4 31 16l-3 32q-3 20-23 26Z" fill={`url(#${id}skin)`} className="ink-outline" strokeWidth="6"/><path d="m334 255 16 3m-13 14 22 2m-18 12 18 2" className="nose-line" strokeWidth="4"/></g>}
      {dizzy && <g className="star-fill"><path d="m70 53 5 12 14 1-11 9 3 14-11-7-12 7 3-14-11-9 14-1Z"/><path d="m325 54 4 11 13 1-10 8 3 13-10-7-11 7 3-13-10-8 13-1Z"/></g>}
    </g>
  </svg>;
}