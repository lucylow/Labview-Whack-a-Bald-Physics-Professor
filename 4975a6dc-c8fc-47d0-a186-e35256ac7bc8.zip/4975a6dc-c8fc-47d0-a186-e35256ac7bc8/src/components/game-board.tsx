import { Button } from '@/components/ui/button';
import { Professor } from './professor';
import type { GameState } from '@/hooks/use-game';
import { Play } from 'lucide-react';
const keys = ['Q', 'W', 'E', 'A', 'S', 'D', 'Z', 'X', 'C'];
export function GameBoard({ state, hit, resume }: { state: GameState; hit: (hole: number) => void; resume: () => void }) {
  return <div className="board-wrap"><div className={`game-board ${state.status === 'playing' ? 'is-playing' : ''}`}>
    {keys.map((key, hole) => {
      const target = state.targets.find(t => t.hole === hole); const feedback = state.feedback?.hole === hole ? state.feedback : null;
      return <Button key={key} variant="hole" className={`game-hole ${target ? 'occupied' : ''} ${target?.kind === 'golden' ? 'golden-hole' : ''} ${target?.kind === 'decoy' ? 'decoy-hole' : ''}`} onPointerDown={event => { if (event.button === 0) { event.preventDefault(); hit(hole); } }} onClick={event => { if (event.detail === 0) hit(hole); }} disabled={state.status !== 'playing'} aria-label={target ? `${target.kind === 'decoy' ? 'Quantum decoy' : target.kind === 'golden' ? 'Golden professor' : 'Professor'} in hole ${hole + 1}` : `Empty hole ${hole + 1}`}>
        <span className="hole-opening"/><span className="hole-character">{target && <Professor expression={target.kind === 'golden' ? 'golden' : target.kind === 'decoy' ? 'shocked' : 'normal'}/>}</span><span className="hole-front"/><span className="hole-key">{key}</span>
        {target?.kind === 'decoy' && <span className="decoy-tag">DECOY</span>}
        {feedback && <span key={feedback.id} className={`hit-points ${feedback.points <= 0 ? 'miss-points' : ''}`}>{feedback.points > 0 ? `+${feedback.points}` : feedback.points < 0 ? feedback.points : 'MISS'}</span>}
      </Button>;
    })}
  </div>{state.status === 'paused' && <div className="board-pause"><h2>Experiment paused</h2><Button variant="arcade" onClick={resume}><Play/>Resume game</Button></div>}</div>;
}