import { useCallback, useEffect, useRef } from 'react';
export type Sound = 'hit' | 'miss' | 'golden' | 'combo' | 'countdown' | 'over' | 'achievement';
export function useSound(enabled: boolean, music: boolean) {
  const context = useRef<AudioContext | null>(null);
  const musicTimer = useRef<ReturnType<typeof setInterval> | null>(null);
  const soundOn = useRef(enabled);
  soundOn.current = enabled;
  const play = useCallback((name: Sound) => {
    if (!soundOn.current) return;
    try {
      const ctx = context.current ?? new AudioContext();
      context.current = ctx;
      void ctx.resume();
      const notes = { hit: [420, 700], miss: [140], golden: [523, 659, 784, 1046], combo: [660, 880], countdown: [520], over: [440, 330, 220], achievement: [523, 784, 1046] }[name];
      notes.forEach((frequency, i) => {
        const oscillator = ctx.createOscillator(); const gain = ctx.createGain();
        oscillator.type = name === 'miss' ? 'sawtooth' : 'sine'; oscillator.frequency.value = frequency;
        const time = ctx.currentTime + i * 0.075;
        gain.gain.setValueAtTime(0.08, time); gain.gain.exponentialRampToValueAtTime(0.001, time + 0.15);
        oscillator.connect(gain); gain.connect(ctx.destination); oscillator.start(time); oscillator.stop(time + 0.16);
      });
    } catch { /* Silent fallback when audio is unavailable. */ }
  }, []);
  useEffect(() => {
    if (music && enabled) {
      let beat = 0;
      musicTimer.current = setInterval(() => { play(beat++ % 4 === 0 ? 'combo' : 'countdown'); }, 900);
    }
    return () => { if (musicTimer.current) clearInterval(musicTimer.current); };
  }, [music, enabled, play]);
  useEffect(() => () => { void context.current?.close(); }, []);
  return play;
}