import { useCallback, useEffect, useRef, useState } from 'react';
import { accuracy, comboBonus, modeDuration, pointsForHit, randomHole, type Mode, type Round, type Settings, type TargetKind } from '@/lib/game';
import type { Sound } from './use-sound';
export type Target = { hole: number; kind: TargetKind; appeared: number; expires: number };
export type GameState = { status: 'idle' | 'playing' | 'paused' | 'ended'; score: number; combo: number; bestCombo: number; hits: number; misses: number; goldenHits: number; remaining: number; targets: Target[]; feedback: { hole: number; points: number; id: number } | null };
const fresh = (mode: Mode): GameState => ({ status: 'idle', score: 0, combo: 0, bestCombo: 0, hits: 0, misses: 0, goldenHits: 0, remaining: modeDuration(mode), targets: [], feedback: null });
export function useGame(mode: Mode, settings: Settings, play: (sound: Sound) => void, onFinish: (round: Round) => void) {
  const [state, setState] = useState<GameState>(() => fresh(mode));
  const current = useRef(state); const deadline = useRef(0); const nextSpawn = useRef(0); const previous = useRef(-1); const finish = useRef(onFinish); const config = useRef(settings);
  finish.current = onFinish; config.current = settings;
  const update = useCallback((value: GameState) => { current.current = value; setState(value); }, []);
  const end = useCallback(() => {
    const s = current.current;
    if (s.status !== 'playing') return;
    const score = Math.max(0, s.score + (mode === 'Endurance' ? 100 : 0));
    update({ ...s, score, remaining: 0, status: 'ended', targets: [] }); play('over');
    finish.current({ id: crypto.randomUUID(), score, hits: s.hits, misses: s.misses, bestCombo: s.bestCombo, goldenHits: s.goldenHits, mode, accuracy: accuracy(s.hits, s.misses), seconds: modeDuration(mode), date: new Date().toISOString(), xp: Math.max(5, Math.floor(score / 10)) });
  }, [mode, play, update]);
  const start = useCallback(() => { const now = performance.now(); deadline.current = now + modeDuration(mode) * 1000; nextSpawn.current = now; previous.current = -1; update({ ...fresh(mode), status: 'playing' }); play('countdown'); }, [mode, play, update]);
  const hit = useCallback((hole: number) => {
    const s = current.current; const now = performance.now();
    if (s.status !== 'playing') return;
    if (now >= deadline.current) { end(); return; }
    const target = s.targets.find(t => t.hole === hole && now < t.expires);
    if (!target) { update({ ...s, combo: 0, misses: s.misses + 1, feedback: { hole, points: 0, id: now } }); play('miss'); return; }
    const decoy = target.kind === 'decoy'; const combo = decoy ? 0 : s.combo + 1;
    const points = pointsForHit(target.kind, mode, now - target.appeared, combo);
    update({ ...s, score: s.score + points, combo, bestCombo: Math.max(s.bestCombo, combo), hits: s.hits + (decoy ? 0 : 1), misses: s.misses + (decoy ? 1 : 0), goldenHits: s.goldenHits + (target.kind === 'golden' ? 1 : 0), targets: s.targets.filter(t => t.hole !== hole), feedback: { hole, points, id: now } });
    play(decoy ? 'miss' : target.kind === 'golden' ? 'golden' : comboBonus(combo) > 0 ? 'combo' : 'hit');
    if (s.targets.length === 1) nextSpawn.current = now + 180;
  }, [mode, end, play, update]);
  const pause = useCallback(() => {
    const s = current.current;
    if (s.status === 'playing') { update({ ...s, status: 'paused', remaining: Math.max(0, (deadline.current - performance.now()) / 1000), targets: [] }); }
    else if (s.status === 'paused') { const now = performance.now(); deadline.current = now + s.remaining * 1000; nextSpawn.current = now; update({ ...s, status: 'playing' }); }
  }, [update]);
  useEffect(() => {
    if (state.status !== 'playing') return;
    const timer = setInterval(() => {
      let s = current.current;
      if (s.status !== 'playing') return;
      const now = performance.now(); if (now >= deadline.current) { end(); return; }
      const remaining = (deadline.current - now) / 1000;
      const missed = s.targets.filter(t => t.expires <= now && t.kind !== 'decoy').length;
      s = { ...s, remaining, targets: s.targets.filter(t => t.expires > now), misses: s.misses + missed, combo: missed > 0 ? 0 : s.combo, feedback: s.feedback && now - s.feedback.id < 650 ? s.feedback : null };
      if (s.targets.length === 0 && now >= nextSpawn.current) {
        const elapsed = modeDuration(mode) - remaining;
        const speed = (mode === 'Sprint' ? 650 : mode === 'Endurance' ? 1100 - Math.floor(elapsed / 15) * 180 : 1050) * (config.current.difficulty === 'Easy' ? 1.4 : config.current.difficulty === 'Hard' ? 0.7 : 1);
        const hole = randomHole(previous.current); previous.current = hole;
        const roll = Math.random();
        const kind: TargetKind = mode === 'Golden Professor' && roll < 0.18 ? 'golden' : (mode === 'Classic' && roll < 0.12) ? 'decoy' : 'normal';
        const targets: Target[] = [{ hole, kind, appeared: now, expires: now + speed }];
        if (mode === 'Quantum Chaos' && roll < 0.6) targets.push({ hole: randomHole(hole), kind: 'decoy', appeared: now, expires: now + speed });
        s = { ...s, targets }; nextSpawn.current = now + speed + 180;
      }
      if (Math.ceil(remaining) <= 3 && Math.ceil(remaining) !== Math.ceil(current.current.remaining)) play('countdown');
      update(s);
    }, 40);
    return () => clearInterval(timer);
  }, [state.status, mode, end, play, update]);
  useEffect(() => {
    const listener = (event: KeyboardEvent) => {
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLSelectElement) return;
      const keys = ['q', 'w', 'e', 'a', 's', 'd', 'z', 'x', 'c']; const index = keys.indexOf(event.key.toLowerCase());
      if (index >= 0) { event.preventDefault(); hit(index); }
      else if (event.key === 'Escape' || event.code === 'Space') { if (current.current.status === 'playing' || current.current.status === 'paused') { event.preventDefault(); pause(); } }
    };
    window.addEventListener('keydown', listener); return () => window.removeEventListener('keydown', listener);
  }, [hit, pause]);
  useEffect(() => {
    const visibility = () => { if (document.hidden && current.current.status === 'playing') pause(); };
    document.addEventListener('visibilitychange', visibility); return () => document.removeEventListener('visibilitychange', visibility);
  }, [pause]);
  return { state, start, hit, pause };
}